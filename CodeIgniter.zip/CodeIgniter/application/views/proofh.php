<!DOCTYPE html>
<html>
<head>
<title>Bienvenido a la Pagina!</title>
</head>
<body>

<h1>Hola a todos, soy el <?php echo $num_viajes; ?></h1>
<p><?php echo $num_incidentes; ?></p>

</body>
</html>



