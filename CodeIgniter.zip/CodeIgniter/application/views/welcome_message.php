<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Prueba de Vista en CodeIgniter!</title>

	
</head>
<body>

<div id="container">
	<h1><?= $string ?> Hola Mundo vía CodeIgniter!</h1>
</div>

</body>
</html>