   <!-- <footer class="page-footer cyan lighten-2">
        <div class="container">

            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">CGMA</h5>
                    <p class="grey-text text-lighten-4">
                         tecnologias de la información
                    </p>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Sitios web</h5>
                    <ul>
                        <li><a class="white-text" href="http://www.df.gob.mx/ciudad/">Ciudad de México</a></li>
                        <li><a class="white-text" href="http://www.df.gob.mx/dependencias/">Gobierno</a></li>
                        <li><a class="white-text" href="http://www.transparencia.df.gob.mx/index.jsp">Transparencia</a></li>
                    </ul>
                </div>
                <div class="col l3 s12">
                    <h5 class="white-text">Contacto</h5>
                    <ul>
                        <li><a class="white-text" href="#!">Link 1</a></li>
                        <li><a class="white-text" href="#!">Link 2</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="footer-copyright">
            <div class="container">
                 Gobierno <a class="orange-text text-lighten-3" href="http://www.df.gob.mx/"> CD MX</a>
            </div>
        </div>

    </footer>-->



</body>
</html>